import tkinter as tk
from startUP import intro
import mysql.connector

mydb = mysql.connector.connect(
   host="localhost",
   user="root"
)

mycursor = mydb.cursor()

def checkDatabase(db):
   mycursor.execute("SHOW DATABASES")
   existD = False
   for i in mycursor:
      if db in i:
         existD = True

   return existD

def checkTable(tb):
   mycursor.execute("SHOW Tables")
   existT = False
   for i in mycursor:
      if tb in i:
         existT = True
   
   return existT


if not (checkDatabase("xyleze")):
   mycursor.execute('CREATE DATABASE xyleze')
mycursor.execute('USE xyleze')
if not (checkTable("users")):
   mycursor.execute("""CREATE TABLE users(
      ID INT AUTO_INCREMENT PRIMARY KEY,
      EMAIL VARCHAR(100),
      PHONE INT(10),
      USERNAME VARCHAR(100),
      PASSWORD VARCHAR(100),
      FIRST_NAME VARCHAR(100),
      LAST_NAME VARCHAR(100)
      )""")

#Creating a empty Tkinter instances
root = tk.Tk()
#Withdrawing the temporary window
root.withdraw()


if __name__ == "__main__":
   #Launching the Intro window
    intro()
    root.mainloop()