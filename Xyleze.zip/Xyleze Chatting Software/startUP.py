from pathlib import Path
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, Toplevel
from loginPage import loginPAGE


OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path("./Assets/startUpAssets")


def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)

def intro():
    INTRO()
    
class INTRO(Toplevel):
    def loginPage(self):
        self.destroy()
        loginPAGE()
        
    def __init__(self, *args, **kwargs):
        Toplevel.__init__(self, *args, **kwargs)
        
        self.geometry("940x524")
        self.configure(bg = "#FFFFFF")


        self.canvas = Canvas(
            self,
            bg = "#FFFFFF",
            height = 524,
            width = 940,
            bd = 0,
            highlightthickness = 0,
            relief = "ridge"
        )

        self.canvas.place(x = 0, y = 0)
        image_image_1 = PhotoImage(
            file=relative_to_assets("image_1.png"))
        image_1 = self.canvas.create_image(
            496.0,
            181.0,
            image=image_image_1
        )

        button_image_1 = PhotoImage(
            file=relative_to_assets("button_1.png"))
        button_1 = Button(
            self.canvas,
            image=button_image_1,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: self.loginPage(),
            relief="flat"
        )
        button_1.place(
            x=305.0,
            y=406.0,
            width=383.0,
            height=81.0
        )
        
        self.resizable(False, False)
        self.mainloop()