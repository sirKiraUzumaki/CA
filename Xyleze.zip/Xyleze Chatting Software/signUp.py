from pathlib import Path
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, Toplevel
from chat import CHAT
from tkinter import messagebox
import mysql.connector

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path("./Assets/signUpAssets")


def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)

global temp
temp = []

def enterData(data):
    connection = mysql.connector.connect(user='root',
                                         host='127.0.0.1',
                                         database='xyleze')
    with connection.cursor() as cursor:
        cursor.execute(data)
        connection.commit()
        
def checkUser(uName):
    connection = mysql.connector.connect(user='root',
                                         host='localhost',
                                         database='xyleze')
    mycursor = connection.cursor()
    mycursor.execute("select username from users")
    for i in mycursor:
        if uName in i:
            return True
        else:
            return False
    
class signUP1(Toplevel):
    
    def __init__(self, *args, **kwargs):
        
        def confirm():
            if not entry_1.get():
                messagebox.showerror('Error!', 'Please enter First Name.')
            if not entry_2.get():
                messagebox.showerror('Error!', 'Please enter Last Name.')
            else:
                temp.append(entry_1.get())
                temp.append(entry_2.get())
                
                enterData(f"""INSERT INTO users VALUES( 
                    '{temp[0]}', {temp[1]}, '{temp[2]}',
                    '{temp[3]}', '{temp[4]}', '{temp[5]}'
                    )""")
                self.destroy()
                CHAT(temp[2])
        
        Toplevel.__init__(self, *args, **kwargs)

        self.geometry("1040x624")
        self.configure(bg = "#FFFFFF")


        self.canvas = Canvas(
            self,
            bg = "#FFFFFF",
            height = 624,
            width = 1040,
            bd = 0,
            highlightthickness = 0,
            relief = "ridge"
        )

        self.canvas.place(x = 0, y = 0)
        entry_image_1 = PhotoImage(
            file=relative_to_assets("entry_13.png"))
        entry_bg_1 = self.canvas.create_image(
            520.5,
            216.5,
            image=entry_image_1
        )
        entry_1 = Entry(
            self.canvas,
            bd=0,
            bg="#D9D9D9",
            highlightthickness=0
        )
        entry_1.place(
            x=319.0,
            y=186.0,
            width=403.0,
            height=59.0
        )

        entry_image_2 = PhotoImage(
            file=relative_to_assets("entry_23.png"))
        entry_bg_2 = self.canvas.create_image(
            520.5,
            328.5,
            image=entry_image_2
        )
        entry_2 = Entry(
            self.canvas,
            bd=0,
            bg="#D9D9D9",
            highlightthickness=0
        )
        entry_2.place(
            x=319.0,
            y=298.0,
            width=403.0,
            height=59.0
        )

        button_image_1 = PhotoImage(
            file=relative_to_assets("button_13.png"))
        button_1 = Button(
            self.canvas,
            cursor="hand2",
            image=button_image_1,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: confirm(),
            relief="flat"
        )
        button_1.place(
            x=395.5547180175781,
            y=450.4280090332031,
            width=249.63775634765625,
            height=70.5719985961914
        )

        image_image_1 = PhotoImage(
            file=relative_to_assets("image_13.png"))
        image_1 = self.canvas.create_image(
            518.0,
            75.0,
            image=image_image_1
        )

        self.canvas.create_text(
            313.0,
            260.0,
            anchor="nw",
            text="Last Name",
            fill="#000000",
            font=("Inter ExtraBold", 30 * -1)
        )

        self.canvas.create_text(
            312.0,
            149.0,
            anchor="nw",
            text="First Name",
            fill="#000000",
            font=("Inter ExtraBold", 30 * -1)
        )
        self.resizable(False, False)
        self.mainloop()

        
        
class signUP0(Toplevel):
    #Username and Password with confirm Password
    
    
    def __init__(self, *args, **kwargs):
        def func():
            if checkUser(entry_1.get()) == False:
                if entry_2.get() == entry_3.get():
                    temp.append(entry_1.get())
                    temp.append(entry_2.get())
                    self.destroy()
                    signUP1()
                else:
                    messagebox.showerror("Error!","Please enter the same password in both feilds!")
            else:
                messagebox.showerror('Error!', 'Username is already taken.')
            
        Toplevel.__init__(self, *args, **kwargs)
        
        self.geometry("1040x624")
        self.configure(bg = "#FFFFFF")


        self.canvas = Canvas(
            self,
            bg = "#FFFFFF",
            height = 624,
            width = 1040,
            bd = 0,
            highlightthickness = 0,
            relief = "ridge"
        )

        self.canvas.place(x = 0, y = 0)
        entry_image_1 = PhotoImage(
            file=relative_to_assets("entry_12.png"))
        entry_bg_1 = self.canvas.create_image(
            507.0,
            208.0,
            image=entry_image_1
        )
        entry_1 = Entry(
            self.canvas,
            bd=0,
            bg="#D9D9D9",
            highlightthickness=0
        )
        entry_1.place(
            x=321.0,
            y=179.0,
            width=372.0,
            height=56.0
        )

        entry_image_2 = PhotoImage(
            file=relative_to_assets("entry_22.png"))
        entry_bg_2 = self.canvas.create_image(
            507.0,
            314.0,
            image=entry_image_2
        )
        entry_2 = Entry(
            self.canvas,
            bd=0,
            bg="#D9D9D9",
            highlightthickness=0,
            show= '*'
        )
        entry_2.place(
            x=321.0,
            y=285.0,
            width=372.0,
            height=56.0
        )

        button_image_1 = PhotoImage(
            file=relative_to_assets("button_12.png"))
        button_1 = Button(
            self.canvas,
            cursor="hand2",
            image=button_image_1,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: func(),
            relief="flat"
        )
        button_1.place(
            x=391.0,
            y=485.0,
            width=231.7653045654297,
            height=66.96656799316406
        )

        image_image_1 = PhotoImage(
            file=relative_to_assets("image_12.png"))
        image_1 = self.canvas.create_image(
            520.0,
            73.0,
            image=image_image_1
        )

        self.canvas.create_text(
            314.0,
            249.0,
            anchor="nw",
            text="Create Password",
            fill="#000000",
            font=("Inter ExtraBold", 30 * -1)
        )

        entry_image_3 = PhotoImage(
            file=relative_to_assets("entry_32.png"))
        entry_bg_3 = self.canvas.create_image(
            507.0,
            420.0,
            image=entry_image_3
        )
        entry_3 = Entry(
            self.canvas,
            bd=0,
            bg="#D9D9D9",
            highlightthickness=0,
            show= '*'
        )
        entry_3.place(
            x=321.0,
            y=391.0,
            width=372.0,
            height=56.0
        )

        self.canvas.create_text(
            314.0,
            355.0,
            anchor="nw",
            text="Confirm Password",
            fill="#000000",
            font=("Inter ExtraBold", 30 * -1)
        )

        self.canvas.create_text(
            313.0,
            144.0,
            anchor="nw",
            text="Create Username",
            fill="#000000",
            font=("Inter ExtraBold", 30 * -1)
        )
        self.resizable(False, False)
        self.mainloop()


class signUP(Toplevel):
    #Email and Phone
    def __init__(self, *args, **kwargs):
        Toplevel.__init__(self, *args, **kwargs)
        
        def func():
            temp.append(entry_1.get())
            temp.append(entry_2.get())
            self.destroy()
            signUP0()
        
        self.geometry("1040x624")
        self.configure(bg = "#FFFFFF")
        
        self.canvas = Canvas(
            self,
            bg = "#FFFFFF",
            height = 624,
            width = 1040,
            bd = 0,
            highlightthickness = 0,
            relief = "ridge"
        )

        self.canvas.place(x = 0, y = 0)
        entry_image_1 = PhotoImage(
            file=relative_to_assets("entry_1.png"))
        entry_bg_1 = self.canvas.create_image(
            520.5,
            232.5,
            image=entry_image_1
        )
        entry_1 = Entry(
            self.canvas,
            bd=0,
            bg="#D9D9D9",
            highlightthickness=0
        )
        entry_1.place(
            x=321.0,
            y=201.0,
            width=399.0,
            height=61.0
        )

        entry_image_2 = PhotoImage(
            file=relative_to_assets("entry_2.png"))
        entry_bg_2 = self.canvas.create_image(
            520.5,
            343.5,
            image=entry_image_2
        )
        entry_2 = Entry(
            self.canvas,
            bd=0,
            bg="#D9D9D9",
            highlightthickness=0
        )
        entry_2.place(
            x=321.0,
            y=312.0,
            width=399.0,
            height=61.0
        )

        button_image_1 = PhotoImage(
            file=relative_to_assets("button_1.png"))
        button_1 = Button(
            self.canvas,
            cursor="hand2",
            image=button_image_1,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: func(),
            relief="flat"
        )
        button_1.place(
            x=396.8341979980469,
            y=441.452880859375,
            width=247.33163452148438,
            height=72.54711151123047
        )

        image_image_1 = PhotoImage(
            file=relative_to_assets("image_1.png"))
        image_1 = self.canvas.create_image(
            520.0,
            73.0,
            image=image_image_1
        )

        self.canvas.create_text(
            315.0,
            274.0,
            anchor="nw",
            text="Phone No.",
            fill="#000000",
            font=("Inter ExtraBold", 30 * -1)
        )

        self.canvas.create_text(
            314.0,
            163.0,
            anchor="nw",
            text="Email",
            fill="#000000",
            font=("Inter ExtraBold", 30 * -1)
        )
        print(entry_1.get())
        self.resizable(False, False)
        self.mainloop()
        print(entry_1.get(),1)