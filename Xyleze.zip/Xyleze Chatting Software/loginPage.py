
from pathlib import Path
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, Toplevel, messagebox
from signUp import signUP
import mysql.connector

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path("./Assets/loginPageAssets")


def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)

def loginPAGE():
    loginP()

connection = mysql.connector.connect(host="localhost",
                                     user="root",
                                     database="xyleze")

mycursor = connection.cursor()

def checkUser(user):
    mycursor.execute("select username from users")
    for i in mycursor:
        if user in i:
            return True
            mycursor.commit()
        else:
            return False
            mycursor.commit()

def checkPass(user, paSS):
    
    mycursor.execute("select password from users where username = '"+user+"'")
    res = mycursor.fetchone()
    if res[0] == paSS:
        return True
    else:
        return False
        
class loginP(Toplevel):
    def sign(self):
        self.destroy()
        signUP()
        
    def __init__(self, *args, **kwargs):
        
        def func():
            userName = entry_1.get()
            password = entry_2.get()
            if checkPass(userName, password):
                print('done')
                self.destroy()
            else:
                messagebox.showerror('Error', 'Wrong Password or Username')
                    
                        
        Toplevel.__init__(self, *args, **kwargs)
    

        self.geometry("1040x624")
        self.configure(bg = "#FFFFFF")


        self.canvas = Canvas(
            self,
            bg = "#FFFFFF",
            height = 624,
            width = 1040,
            bd = 0,
            highlightthickness = 0,
            relief = "ridge"
        )

        self.canvas.place(x = 0, y = 0)
        entry_image_1 = PhotoImage(
            file=relative_to_assets("entry_1.png"))
        entry_bg_1 = self.canvas.create_image(
            520.0,
            189.5,
            image=entry_image_1
        )
        entry_1 = Entry(
            self.canvas,
            bd=0,
            bg="#D9D9D9",
            highlightthickness=0
        )
        entry_1.place(
            x=339.0,
            y=160.0,
            width=362.0,
            height=57.0
        )

        entry_image_2 = PhotoImage(
            file=relative_to_assets("entry_2.png"))
        entry_bg_2 = self.canvas.create_image(
            520.0,
            293.5,
            image=entry_image_2
        )
        entry_2 = Entry(
            self.canvas,
            bd=0,
            bg="#D9D9D9",
            highlightthickness=0
        )
        entry_2.place(
            x=339.0,
            y=264.0,
            width=362.0,
            height=57.0
        )

        button_image_1 = PhotoImage(
            file=relative_to_assets("button_1.png"))
        button_1 = Button(
            self.canvas,
            cursor="hand2",
            image=button_image_1,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: func(),
            relief="flat"
        )
        button_1.place(
            x=407.0,
            y=385.0,
            width=226.0,
            height=68.0
        )

        self.canvas.create_text(
            494.0,
            469.0,
            anchor="nw",
            text="or",
            fill="#000000",
            font=("Inter ExtraBold", 25 * -1)
        )

        button_image_2 = PhotoImage(
            file=relative_to_assets("button_2.png"))
        button_2 = Button(
            self.canvas,
            cursor="hand2",
            image=button_image_2,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: self.sign(),
            relief="flat"
        )
        button_2.place(
            x=358.0,
            y=516.0,
            width=323.0,
            height=79.0
        )

        image_image_1 = PhotoImage(
            file=relative_to_assets("image_1.png"))
        image_1 = self.canvas.create_image(
            520.0,
            73.0,
            image=image_image_1
        )

        button_image_3 = PhotoImage(
            file=relative_to_assets("button_3.png"))
        button_3 = Button(
            self.canvas,
            cursor="hand2",
            image=button_image_3,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: print("button_3 clicked"),
            relief="flat"
        )
        button_3.place(
            x=324.0,
            y=328.0,
            width=136.0,
            height=16.0
        )
        self.resizable(False, False)
        self.mainloop()